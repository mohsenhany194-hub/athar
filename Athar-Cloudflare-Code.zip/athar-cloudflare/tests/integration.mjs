import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,mkdtemp,rm} from 'node:fs/promises';
import {pbkdf2Sync,randomBytes,randomUUID,createHmac} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import os from 'node:os';

const root=fileURLToPath(new URL('..',import.meta.url));
const pages=process.argv.includes('--pages');
const require=createRequire(import.meta.url);
const {Miniflare}=createRequire(require.resolve('wrangler/package.json'))('miniflare');
const temporary=await mkdtemp(path.join(os.tmpdir(),'athar-test-'));
const origin='https://athar.example';
const password=randomBytes(24).toString('base64url');
const salt=randomBytes(16);
const bindings={ADMIN_EMAIL:'magedsamir996@gmail.com',ADMIN_PASSWORD_HASH:`pbkdf2-sha256$100000$${salt.toString('base64url')}$${pbkdf2Sync(password,salt,100000,32,'sha256').toString('base64url')}`,SESSION_SECRET:randomBytes(32).toString('base64url')};
const options={
  modules:true,scriptPath:path.join(root,pages?'pages/cloudflare-upload/_worker.js':'dist/athar_watch_store/index.js'),
  compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],
  bindings,d1Databases:{DB:'integration-db'},r2Buckets:{BUCKET:'integration-images'},
  d1Persist:path.join(temporary,'d1'),r2Persist:path.join(temporary,'r2'),
  assets:{directory:path.join(root,pages?'pages/cloudflare-upload':'dist/client'),binding:'ASSETS',routerConfig:{has_user_worker:true,invoke_user_worker_ahead_of_assets:true},assetConfig:{not_found_handling:'single-page-application'}},
};
let mf;let cookie='';let checks=0;
function check(value,message){assert.ok(value,message);checks++;}
async function request(route,{body,auth=false,headers={},method=body===undefined?'GET':'POST'}={}){
  return mf.dispatchFetch(origin+route,{method,headers:{...(method==='GET'?{}:{Origin:origin}),...(body===undefined?{}:{'Content-Type':'application/json'}),...(auth?{Cookie:cookie}:{}),...headers},...(body===undefined?{}:{body:JSON.stringify(body)})});
}
async function admin(body){const r=await request('/api/admin',{body,auth:true});check(r.ok,'Admin save succeeds');return r.json();}
try{
  mf=new Miniflare(options);await mf.ready;
  let r=await request('/api/store');if(!r.ok)console.error('Catalog response:',r.status,await r.clone().text());check(r.ok,'Public catalog needs no login');check(r.headers.get('cache-control')==='no-store','Catalog updates are not cached');
  const catalog=await r.json();check(catalog.products.length===31,'Catalog contains all 31 products');
  check(catalog.products.reduce((n,p)=>n+p.variants.length,0)===67,'Catalog contains all 67 variants');
  check(catalog.products.every(p=>p.inventory===null&&[200,250].includes(p.price)),'Unlimited stock and prices preserved');
  check(catalog.settings.shipping.length===27,'All governorates preserved');
  const assets=new Set(catalog.products.flatMap(p=>p.variants.flatMap(v=>v.images).concat(p.gallery||[])).concat(catalog.settings.logo));
  for(const file of assets){const response=await request(file);check(response.ok&&response.headers.get('Content-Type')?.startsWith('image/'),'Product asset resolves: '+file);}
  r=await request('/admin');check(r.ok&&(await r.text()).includes('id="root"'),'Direct admin URL serves the application');
  check((await request('/api/admin')).status===403,'Guest cannot read admin data');
  check((await request('/api/auth/session')).status===401,'Guest has no session');
  check((await request('/api/admin',{headers:{'x-oai-user-email':bindings.ADMIN_EMAIL,'x-oai-user-id':'forged'}})).status===403,'ChatGPT identity headers do not grant access');
  check((await request('/api/auth/login',{body:{email:bindings.ADMIN_EMAIL,password},headers:{Origin:'https://another.example'}})).status===403,'Cross-origin login rejected');
  check((await request('/api/auth/login',{body:{email:bindings.ADMIN_EMAIL,password:'incorrect'}})).status===401,'Wrong password rejected');
  check((await request('/api/auth/login',{body:{email:'maged.samir996@gmail.com',password}})).status===401,'Email stays exactly without a dot');
  r=await request('/api/auth/login',{body:{email:bindings.ADMIN_EMAIL,password}});check(r.ok,'Owner can log in');
  const setCookie=r.headers.get('set-cookie');check(setCookie?.includes('HttpOnly')&&setCookie.includes('Secure')&&setCookie.includes('SameSite=Strict')&&setCookie.startsWith('__Host-athar-admin='),'Production cookie is protected');
  cookie=setCookie.split(';')[0];
  check((await request('/api/auth/session',{auth:true})).ok,'Signed session accepted');
  const changedCookie=cookie.slice(0,-8)+'corrupted';
  check((await request('/api/admin',{headers:{Cookie:changedCookie}})).status===403,'Tampered session rejected');
  const past=Math.floor(Date.now()/1000)-9*3600;
  const expired=Buffer.from(JSON.stringify({email:bindings.ADMIN_EMAIL,origin,iat:past,exp:past+8*3600})).toString('base64url');
  const signedExpired=expired+'.'+createHmac('sha256',bindings.SESSION_SECRET+'\n'+bindings.ADMIN_PASSWORD_HASH).update(expired).digest('base64url');
  check((await request('/api/admin',{headers:{Cookie:'__Host-athar-admin='+signedExpired}})).status===403,'Expired session rejected');
  let p=structuredClone(catalog.products[0]);
  check((await request('/api/admin',{body:{action:'saveProduct',product:p}})).status===403,'Guest cannot modify products');
  check((await request('/api/admin',{auth:true,body:{action:'saveProduct',product:p},headers:{Origin:'https://another.example'}})).status===403,'Cross-origin admin modification rejected');
  p.available=false;await admin({action:'saveProduct',product:p});
  check((await (await request('/api/store')).json()).products.find(x=>x.id===p.id).available===false,'Sold-out change reaches the public catalog');
  const order={name:'عميل اختبار',phone:'٠١٠١٢٣٤٥٦٧٨',email:'',governorate:'القاهرة',city:'مدينة نصر',address:'شارع اختبار، عمارة ١، شقة ١',notes:'Integration test only',payment:'cod',items:[{productId:p.id,variantId:p.variants[0].id,quantity:2,unitPrice:1}],idempotencyKey:randomUUID()};
  check((await request('/api/orders',{body:order})).status===409,'Sold-out product cannot be ordered');
  p.available=true;p.variants[0].available=false;await admin({action:'saveProduct',product:p});
  check((await request('/api/orders',{body:order})).status===409,'Sold-out color cannot be ordered');
  p.variants[0].available=true;p.salePrice=p.price-20;await admin({action:'saveProduct',product:p});
  check((await request('/api/orders',{body:order,headers:{Origin:'https://another.example'}})).status===403,'Cross-origin order rejected');
  r=await request('/api/orders',{body:order});check(r.status===201,'Guest can place an order');const receipt=await r.json();
  check(receipt.total===2*p.salePrice+70,'Server calculates real price and Cairo delivery');
  check(receipt.notificationStatus==='not_connected','Automatic WhatsApp is not falsely reported as connected');
  const repeat=await (await request('/api/orders',{body:order})).json();check(repeat.number===receipt.number&&repeat.total===receipt.total,'Duplicate submission returns the original receipt');
  let data=await (await request('/api/admin',{auth:true})).json();check(data.orders.length===1,'One saved order for duplicate requests');
  check(data.orders[0].phone==='01012345678','Arabic phone digits normalize');
  await admin({action:'updateOrder',id:data.orders[0].id,status:'confirmed',adminNotes:'تم التأكيد'});
  data=await (await request('/api/admin',{auth:true})).json();check(data.orders[0].status==='confirmed'&&data.orders[0].adminNotes==='تم التأكيد','Order status and notes save');
  const settings=structuredClone(data.settings);settings.heroTitle='عنوان اختبار';settings.shipping[0].price=80;
  await admin({action:'saveSettings',settings});check((await (await request('/api/store')).json()).settings.heroTitle==='عنوان اختبار','Store settings save');
  const added={...p,id:'integration-product',name:'منتج اختبار جديد',hidden:false,salePrice:null,variants:[{...p.variants[0],id:'integration-variant'}]};
  await admin({action:'saveProduct',product:added});check((await (await request('/api/store')).json()).products.length===32,'Admin can add a product');
  await admin({action:'deleteProduct',id:added.id});check((await (await request('/api/store')).json()).products.length===31,'Admin can delete a product');
  const imagePath=[...assets][0];const bytes=await readFile(path.join(root,'public',imagePath));
  const form=new FormData();form.append('file',new File([bytes],'watch.webp',{type:'image/webp'}));
  const multipart=new Request(origin+'/api/upload',{method:'POST',body:form});
  const multipartBody=await multipart.arrayBuffer();const multipartType=multipart.headers.get('Content-Type');
  r=await mf.dispatchFetch(origin+'/api/upload',{method:'POST',headers:{Origin:origin,'Content-Type':multipartType},body:multipartBody});check(r.status===403,'Guest cannot upload');
  r=await mf.dispatchFetch(origin+'/api/upload',{method:'POST',headers:{Origin:origin,Cookie:cookie,'Content-Type':multipartType},body:multipartBody});check(r.ok,'Owner can upload an image');
  const upload=await r.json();r=await request(upload.url);check(r.ok&&r.headers.get('content-type')==='image/webp','Uploaded R2 image is viewable');
  check(Buffer.from(await r.arrayBuffer()).equals(bytes),'Uploaded bytes are preserved');
  await mf.dispose();mf=new Miniflare(options);await mf.ready;
  data=await (await request('/api/admin',{auth:true})).json();check(data.orders[0].status==='confirmed'&&data.settings.heroTitle==='عنوان اختبار','D1 changes survive a restart');
  check((await request(upload.url)).ok,'R2 image survives a restart');
  r=await request('/api/auth/logout',{method:'POST',auth:true});check(r.ok&&r.headers.get('set-cookie')?.includes('Max-Age=0'),'Logout clears the browser cookie');
  cookie='';check((await request('/api/admin',{auth:true})).status===403,'Logged-out visitor cannot access admin');
  const currentDb=await mf.getD1Database('DB');await currentDb.prepare('DELETE FROM login_attempts').run();
  for(let i=0;i<10;i++)check((await request('/api/auth/login',{body:{email:bindings.ADMIN_EMAIL,password:'incorrect'}})).status===401,'Invalid attempt is rejected');
  check((await request('/api/auth/login',{body:{email:bindings.ADMIN_EMAIL,password}})).status===429,'Login attempts are limited');
  await mf.setOptions({...options,bindings:{...bindings,SESSION_SECRET:randomBytes(32).toString('base64url')}});
  check((await request('/api/auth/session',{headers:{Cookie:setCookie.split(';')[0]}})).status===401,'Secret rotation invalidates earlier sessions');
  await mf.setOptions({...options,bindings:{ADMIN_EMAIL:bindings.ADMIN_EMAIL}});
  check((await request('/api/store')).ok,'Public catalog works before admin secrets are set');
  check((await request('/api/auth/login',{body:{email:bindings.ADMIN_EMAIL,password}})).status===503,'Unconfigured login stays closed and explains setup');
  console.log(`PASS (${pages?'Pages':'Workers'}): ${checks} checks — automatic schema, public catalog, assets, login protection, products, settings, orders, R2, persistence and rate limiting.`);
}finally{
  if(mf)await mf.dispose();
  await rm(temporary,{recursive:true,force:true});
}
