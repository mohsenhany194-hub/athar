import {env} from 'cloudflare:workers';
import {initialProducts} from './catalog';
import {initialSettings} from './settings';
import {ensureSchema} from './schema';
import type {Product,Settings,Order} from './types';
export function database(){if(!env.DB)throw new Error('Database unavailable');return env.DB;}
export async function ensureSeed(){await ensureSchema();const db=database();const seed=await db.prepare('SELECT id FROM settings WHERE id = ?').bind('seed-v1').first();if(seed)return;await db.batch([...initialProducts.map(p=>db.prepare('INSERT OR IGNORE INTO products (id,data,deleted) VALUES (?,?,0)').bind(p.id,JSON.stringify(p))),db.prepare('INSERT OR IGNORE INTO settings (id,data) VALUES (?,?)').bind('store',JSON.stringify(initialSettings)),db.prepare('INSERT OR IGNORE INTO settings (id,data) VALUES (?,?)').bind('seed-v1','{}')]);}
export async function readStore(admin=false){await ensureSeed();const db=database();const rows=await db.prepare('SELECT data FROM products WHERE deleted=0').all<{data:string}>();const products=rows.results.map(x=>JSON.parse(x.data) as Product).filter(x=>admin||!x.hidden).sort((a,b)=>a.sortOrder-b.sortOrder);const row=await db.prepare('SELECT data FROM settings WHERE id=?').bind('store').first<{data:string}>();const settings:Settings={...initialSettings,...JSON.parse(row!.data)};if(!admin)settings.notification={enabled:false,phoneNumberId:'',templateName:'',language:'ar'};return {products,settings};}
export async function readOrders(){const rows=await database().prepare('SELECT data FROM orders ORDER BY created_at DESC LIMIT 500').all<{data:string}>();return rows.results.map(x=>JSON.parse(x.data) as Order);}
