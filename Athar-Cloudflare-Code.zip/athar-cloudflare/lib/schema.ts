import {env} from 'cloudflare:workers';

// Initialize fresh D1 databases. Existing products and orders stay in place.
const statements=[
  'CREATE TABLE IF NOT EXISTS products (id TEXT PRIMARY KEY NOT NULL, data TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0)',
  'CREATE TABLE IF NOT EXISTS settings (id TEXT PRIMARY KEY NOT NULL, data TEXT NOT NULL)',
  'CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY NOT NULL, idempotency_key TEXT NOT NULL, created_at TEXT NOT NULL, status TEXT NOT NULL, data TEXT NOT NULL)',
  'CREATE UNIQUE INDEX IF NOT EXISTS orders_idempotency_key_unique ON orders (idempotency_key)',
  'CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders (created_at)',
  'CREATE TABLE IF NOT EXISTS login_attempts (key TEXT PRIMARY KEY NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, expires_at INTEGER NOT NULL)',
  'CREATE INDEX IF NOT EXISTS login_attempts_expiry ON login_attempts (expires_at)',
];
let initialization:Promise<void>|undefined;
export async function ensureSchema(){
  if(!env.DB)throw new Error('D1 binding DB is not configured');
  initialization??=env.DB.batch(statements.map(sql=>env.DB.prepare(sql))).then(()=>{});
  try{await initialization;}catch(error){initialization=undefined;throw error;}
}
