import type {Product} from './types';
import snapshot from './catalog-snapshot.json';
export const initialProducts:Product[]=snapshot as Product[];
