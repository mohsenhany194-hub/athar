export type Variant={id:string;name:string;color:string;images:string[];available:boolean};
export type Product={id:string;name:string;description:string;category:'women'|'men';price:number;salePrice:number|null;variants:Variant[];available:boolean;hidden:boolean;featured:boolean;sortOrder:number;inventory:null;gallery?:string[]};
export type Shipping={name:string;price:number};
export type Settings={brandName:string;tagline:string;heroTitle:string;heroText:string;announcement:string;catalogTitle:string;footerText:string;logo:string;accentColor:string;backgroundColor:string;whatsapp:string;facebook:string;instapay:string;wallet:string;shipping:Shipping[];payments:{cod:boolean;instapay:boolean;wallet:boolean};heroInterval:number;heroIds:string[];notification:{enabled:boolean;phoneNumberId:string;templateName:string;language:string}};
export type CartItem={productId:string;variantId:string;quantity:number};
export type OrderItem=CartItem&{name:string;variant:string;image:string;unitPrice:number};
export type Order={id:string;number:string;createdAt:string;name:string;phone:string;email:string;governorate:string;city:string;address:string;notes:string;payment:'cod'|'instapay'|'wallet';subtotal:number;shipping:number;total:number;items:OrderItem[];status:string;notificationStatus:string;adminNotes:string;idempotencyKey:string};
