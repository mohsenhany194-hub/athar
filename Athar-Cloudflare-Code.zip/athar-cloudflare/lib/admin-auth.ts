import {sessionUser} from '@/worker/auth';
export async function isAdmin(request:Request){return !!await sessionUser(request);}
export function sameOrigin(request:Request){
  return request.headers.get('sec-fetch-site')!=='cross-site'&&request.headers.get('origin')===new URL(request.url).origin;
}
