import {ZodError} from 'zod';
import {database,readStore} from '@/lib/db';
import {orderSchema} from '@/lib/validation';
import {sameOrigin} from '@/lib/admin-auth';
import {notifyOrder,orderMessage,phoneInternational} from '@/lib/whatsapp';
import type {Order,Settings} from '@/lib/types';

function receipt(order:Order,settings:Settings){
 return {number:order.number,total:order.total,notificationStatus:order.notificationStatus,
  whatsappUrl:`https://wa.me/${phoneInternational(settings.whatsapp)}?text=${encodeURIComponent(orderMessage(order))}`};
}
export async function POST(request:Request){
 if(!sameOrigin(request))return Response.json({error:'طلب غير مسموح'},{status:403});
 try{
  const {website,...b}=orderSchema.parse(await request.json());
  const db=database();
  const {products,settings}=await readStore();
  const duplicate=await db.prepare('SELECT data FROM orders WHERE idempotency_key=?').bind(b.idempotencyKey).first<{data:string}>();
  if(duplicate)return Response.json(receipt(JSON.parse(duplicate.data) as Order,settings));
  if(!settings.payments[b.payment])return Response.json({error:'طريقة الدفع دي مش متاحة دلوقتي'},{status:400});
  const delivery=settings.shipping.find(x=>x.name===b.governorate);
  if(!delivery)return Response.json({error:'اختاري المحافظة'},{status:400});
  const items=b.items.map(i=>{
   const p=products.find(x=>x.id===i.productId);
   const v=p?.variants.find(x=>x.id===i.variantId);
   if(!p||!v||!p.available||!v.available)throw new Error('OUT_OF_STOCK');
   return {...i,name:p.name,variant:v.name,image:v.images[0],unitPrice:p.salePrice??p.price};
  });
  const subtotal=items.reduce((s,i)=>s+i.unitPrice*i.quantity,0);
  const id=crypto.randomUUID();
  const o:Order={...b,id,number:'AT-'+Date.now().toString(36).toUpperCase()+'-'+id.slice(0,4).toUpperCase(),createdAt:new Date().toISOString(),subtotal,shipping:delivery.price,total:subtotal+delivery.price,items,status:'new',notificationStatus:'pending',adminNotes:''};
  const result=await db.prepare('INSERT OR IGNORE INTO orders (id,idempotency_key,created_at,status,data) VALUES (?,?,?,?,?)').bind(o.id,o.idempotencyKey,o.createdAt,o.status,JSON.stringify(o)).run();
  if(!result.meta.changes){
   const saved=await db.prepare('SELECT data FROM orders WHERE idempotency_key=?').bind(o.idempotencyKey).first<{data:string}>();
   return Response.json(receipt(JSON.parse(saved!.data) as Order,settings));
  }
  try{
   o.notificationStatus=await notifyOrder(o,settings);
   await db.prepare('UPDATE orders SET data=? WHERE id=?').bind(JSON.stringify(o),o.id).run();
  }catch(e){console.error('Saved order notification failed',e);o.notificationStatus='failed';}
  return Response.json(receipt(o,settings),{status:201});
 }catch(e){
  if(e instanceof Error&&e.message==='OUT_OF_STOCK')return Response.json({error:'واحدة من الساعات خلصت. حدّثي السلة واختاري موديل متاح.'},{status:409});
  if(e instanceof ZodError)return Response.json({error:e.issues[0]?.message||'راجعي بيانات الطلب.'},{status:400});
  if(e instanceof SyntaxError)return Response.json({error:'راجعي بيانات الطلب.'},{status:400});
  console.error('Order failed',e);
  return Response.json({error:'تعذّر حفظ الطلب. جرّبي تاني، بياناتك لسه موجودة.'},{status:503});
 }
}
