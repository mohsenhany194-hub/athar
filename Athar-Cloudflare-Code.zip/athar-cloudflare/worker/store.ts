import {readStore} from '@/lib/db';

export async function GET(){try{return Response.json(await readStore(),{headers:{'Cache-Control':'no-store'}})}catch(e){console.error('Store load failed',e);return Response.json({error:'المتجر مش متاح مؤقتًا. جرّبي تاني بعد شوية.'},{status:503})}}
