import {env} from 'cloudflare:workers';
import {ensureSchema} from '../lib/schema';

const lifetime=8*60*60;
const encoder=new TextEncoder();
const json=(body:unknown,status=200,headers?:HeadersInit)=>Response.json(body,{status,headers});
const email=()=>env.ADMIN_EMAIL?.trim().toLowerCase();
const configured=()=>!!email()&&!!env.ADMIN_PASSWORD_HASH&&!!env.SESSION_SECRET&&env.SESSION_SECRET.length>=32;
const cookieName=(request:Request)=>new URL(request.url).protocol==='https:'?'__Host-athar-admin':'athar-admin-local';
function encode(bytes:Uint8Array){let s='';for(const b of bytes)s+=String.fromCharCode(b);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function decode(s:string){if(!/^[a-zA-Z0-9_-]+$/.test(s))throw new Error('Invalid encoding');return Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));}
async function signingKey(){return crypto.subtle.importKey('raw',encoder.encode(env.SESSION_SECRET+'\n'+env.ADMIN_PASSWORD_HASH),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);}
function sameOrigin(request:Request){return request.headers.get('sec-fetch-site')!=='cross-site'&&request.headers.get('origin')===new URL(request.url).origin;}
function cookie(request:Request,value:string,age:number){return `${cookieName(request)}=${value}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${age}${new URL(request.url).protocol==='https:'?'; Secure':''}`;}

export async function sessionUser(request:Request):Promise<{email:string}|null>{
  if(!configured())return null;
  const raw=request.headers.get('cookie')?.split(';').map(c=>c.trim()).find(c=>c.startsWith(cookieName(request)+'='))?.slice(cookieName(request).length+1);
  if(!raw||raw.length>4096)return null;
  try{
    const [payload,signature,extra]=raw.split('.');
    if(!payload||!signature||extra||!await crypto.subtle.verify('HMAC',await signingKey(),decode(signature),encoder.encode(payload)))return null;
    const data=JSON.parse(new TextDecoder().decode(decode(payload)));
    const now=Math.floor(Date.now()/1000);
    if(data.email!==email()||data.origin!==new URL(request.url).origin||!Number.isInteger(data.exp)||!Number.isInteger(data.iat)||data.iat>now+30||data.exp<=now||data.exp-data.iat!==lifetime)return null;
    return {email:data.email};
  }catch{return null;}
}

async function passwordMatches(password:string){
  try{
    const [algorithm,iterations,salt,expected,extra]=env.ADMIN_PASSWORD_HASH!.split('$');
    if(algorithm!=='pbkdf2-sha256'||iterations!=='100000'||extra)return false;
    const saltBytes=decode(salt);const expectedBytes=decode(expected);
    if(saltBytes.length!==16||expectedBytes.length!==32)return false;
    const key=await crypto.subtle.importKey('raw',encoder.encode(password),'PBKDF2',false,['deriveBits']);
    const derived=new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:saltBytes,iterations:100000},key,256));
    let difference=0;for(let i=0;i<32;i++)difference|=derived[i]^expectedBytes[i];return difference===0;
  }catch{return false;}
}

export async function login(request:Request){
  if(!sameOrigin(request))return json({error:'طلب غير مسموح'},403);
  if(!configured())return json({error:'دخول الإدارة محتاج إعداد كلمة المرور في حساب Cloudflare.'},503);
  if(Number(request.headers.get('content-length')||0)>4096)return json({error:'بيانات الدخول غير صالحة'},400);
  const bodyText=await request.text();if(bodyText.length>4096)return json({error:'بيانات الدخول غير صالحة'},400);
  let body:{email?:unknown;password?:unknown};try{body=JSON.parse(bodyText);}catch{return json({error:'بيانات الدخول غير صالحة'},400);}
  if(typeof body.email!=='string'||body.email.length>254||typeof body.password!=='string'||body.password.length>256)return json({error:'بيانات الدخول غير صالحة'},400);
  await ensureSchema();
  const now=Math.floor(Date.now()/1000);
  const ip=request.headers.get('CF-Connecting-IP')||'local';
  const digest=encode(new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(env.SESSION_SECRET+'\n'+ip))));
  const key=digest+':'+Math.floor(now/900);
  await env.DB.prepare('DELETE FROM login_attempts WHERE expires_at < ?').bind(now).run();
  const attempt=await env.DB.prepare('INSERT INTO login_attempts (key,attempts,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET attempts=attempts+1 RETURNING attempts').bind(key,now+900).first<{attempts:number}>();
  if(!attempt||attempt.attempts>10)return json({error:'محاولات كتير. استنّى ١٥ دقيقة وجرّب تاني.'},429,{'Retry-After':'900'});
  const valid=await passwordMatches(body.password);
  if(!valid||body.email.trim().toLowerCase()!==email())return json({error:'الإيميل أو كلمة المرور مش صحيحين'},401);
  const payload=encode(encoder.encode(JSON.stringify({email:email(),origin:new URL(request.url).origin,iat:now,exp:now+lifetime})));
  const signature=encode(new Uint8Array(await crypto.subtle.sign('HMAC',await signingKey(),encoder.encode(payload))));
  return json({email:email()},200,{'Set-Cookie':cookie(request,payload+'.'+signature,lifetime)});
}

export async function logout(request:Request){
  if(!sameOrigin(request))return json({error:'طلب غير مسموح'},403);
  return json({ok:true},200,{'Set-Cookie':cookie(request,'',0)});
}
