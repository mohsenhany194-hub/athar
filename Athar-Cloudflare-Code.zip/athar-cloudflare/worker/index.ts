import {GET as store} from './store';
import {GET as adminGet,POST as adminPost} from './admin';
import {POST as order} from './orders';
import {POST as upload} from './upload';
import {GET as media} from './media';
import {login,logout,sessionUser} from './auth';

export default {
  async fetch(request:Request,env:Cloudflare.Env):Promise<Response>{
    const {pathname}=new URL(request.url);
    if(!pathname.startsWith('/api/'))return env.ASSETS.fetch(request);
    let response:Response;
    try{
      if(pathname==='/api/store'&&request.method==='GET')response=await store();
      else if(pathname==='/api/admin'&&request.method==='GET')response=await adminGet(request);
      else if(pathname==='/api/admin'&&request.method==='POST')response=await adminPost(request);
      else if(pathname==='/api/orders'&&request.method==='POST')response=await order(request);
      else if(pathname==='/api/upload'&&request.method==='POST')response=await upload(request);
      else if(pathname.startsWith('/api/media/')&&request.method==='GET')response=await media(request,{params:Promise.resolve({id:pathname.slice('/api/media/'.length)})});
      else if(pathname==='/api/auth/login'&&request.method==='POST')response=await login(request);
      else if(pathname==='/api/auth/logout'&&request.method==='POST')response=await logout(request);
      else if(pathname==='/api/auth/session'&&request.method==='GET'){
        const user=await sessionUser(request);
        response=Response.json(user?{authenticated:true,email:user.email}:{authenticated:false},{status:user?200:401});
      }
      else response=Response.json({error:'الصفحة مش موجودة'},{status:404});
    }catch(error){console.error('Request failed',error);response=Response.json({error:'الخدمة مش متاحة مؤقتًا. جرّبي تاني.'},{status:503});}
    const headers=new Headers(response.headers);
    headers.set('X-Content-Type-Options','nosniff');headers.set('Referrer-Policy','strict-origin-when-cross-origin');
    if(!pathname.startsWith('/api/media/'))headers.set('Cache-Control','no-store');
    return new Response(response.body,{status:response.status,headers});
  }
};
