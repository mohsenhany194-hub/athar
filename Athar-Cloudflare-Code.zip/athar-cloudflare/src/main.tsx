import {useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import Store from './store';
import Admin from './admin';
import type {Product,Settings} from '@/lib/types';
import './globals.css';

function Login({onLogin}:{onLogin:(email:string)=>void}){
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [error,setError]=useState('');
  const [busy,setBusy]=useState(false);
  async function submit(e:React.FormEvent){
    e.preventDefault();setBusy(true);setError('');
    try{
      const r=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});
      const data=await r.json() as {email:string;error?:string};
      if(!r.ok)throw new Error(data.error||'تعذّر الدخول');
      setPassword('');onLogin(data.email);
    }catch(e){setError(e instanceof Error?e.message:'تعذّر الدخول. جرّبي تاني.');}
    finally{setBusy(false);}
  }
  return <main className="access-page login-page"><a href="/" className="footer-brand">Athar</a><h1>دخول لوحة الإدارة</h1><p>اكتب إيميل الإدارة وكلمة المرور.</p><form className="login-form" onSubmit={submit}><label>الإيميل<input dir="ltr" type="email" required maxLength={254} autoComplete="username" value={email} onChange={e=>setEmail(e.target.value)}/></label><label>كلمة المرور<input dir="ltr" type="password" required maxLength={256} autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)}/></label>{error&&<p role="alert" className="error-text">{error}</p>}<button className="gold-button" disabled={busy}>{busy?'جاري الدخول…':'دخول'}</button></form><a className="text-button" href="/">الرجوع للمتجر</a></main>;
}

function App(){
  const admin=location.pathname==='/admin'||location.pathname==='/admin/';
  const [store,setStore]=useState<{products:Product[];settings:Settings}|null>(null);
  const [user,setUser]=useState<string|null>(null);
  const [loaded,setLoaded]=useState(false);
  const [error,setError]=useState('');
  useEffect(()=>{
    const abort=new AbortController();
    fetch(admin?'/api/auth/session':'/api/store',{signal:abort.signal})
      .then(async r=>{
        if(admin){
          const d=await r.json() as {email?:string;error?:string};
          if(r.ok&&typeof d.email==='string')setUser(d.email);
          else if(r.status!==401)throw new Error(d.error||'تعذّر تحميل الإدارة');
        }else{
          const d=await r.json() as {products:Product[];settings:Settings;error?:string};
          if(!r.ok)throw new Error(d.error||'المتجر مش متاح مؤقتًا');
          setStore(d);document.title=d.settings.brandName+' | '+d.settings.tagline;
        }
      })
      .catch(e=>{if(e.name!=='AbortError')setError(e.message||'تعذّر تحميل الموقع');})
      .finally(()=>{if(!abort.signal.aborted)setLoaded(true);});
    return()=>abort.abort();
  },[admin]);
  async function signOut(){
    const r=await fetch('/api/auth/logout',{method:'POST'});
    if(r.ok){setUser(null);location.assign('/admin');}
  }
  if(error)return <main className="access-page"><h1>أثر</h1><p role="alert" className="error-text">{error}</p><button className="gold-button" onClick={()=>location.reload()}>إعادة المحاولة</button><a href="/">الرجوع للمتجر</a></main>;
  if(!loaded)return <main className="access-page"><span className="footer-brand">Athar</span><p role="status">بنجهز {admin?'لوحة الإدارة':'الساعات'}…</p></main>;
  if(admin)return user?<Admin displayName={user} onSignOut={signOut}/>:<Login onLogin={setUser}/>;
  return store?<Store initial={store}/>:null;
}
createRoot(document.getElementById('root')!).render(<App/>);
