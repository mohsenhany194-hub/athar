import {cp, mkdir, readFile, rm, writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const root=fileURLToPath(new URL('..',import.meta.url));
const target=path.join(root,'pages/cloudflare-upload');
await rm(target,{recursive:true,force:true});
await mkdir(target,{recursive:true});
await cp(path.join(root,'dist/client'),target,{recursive:true});
const worker=await readFile(path.join(root,'dist/athar_watch_store/index.js'),'utf8');
await writeFile(path.join(target,'_worker.js'),worker.replace(/^\/\/#(?:end)?region[^\n]*\n/gm,''));
await writeFile(path.join(target,'_routes.json'),JSON.stringify({version:1,include:['/api/*'],exclude:[]},null,2)+'\n');
// Vite generates a Workers-only deploy redirect; Pages uses pages/wrangler.jsonc.
await rm(path.join(root,'.wrangler/deploy/config.json'),{force:true});
if(!worker.includes('cloudflare:workers')||!worker.includes('sessionUser')){
  throw new Error('Unexpected Worker output. Build the source before preparing Pages.');
}
console.log('Pages upload is ready in pages/cloudflare-upload/. Configure DB, BUCKET, ADMIN_EMAIL and the two secrets before publishing.');
