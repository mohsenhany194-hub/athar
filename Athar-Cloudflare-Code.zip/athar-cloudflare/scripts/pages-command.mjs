import {rm,access} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const root=fileURLToPath(new URL('..',import.meta.url));
const [command,...args]=process.argv.slice(2);
if(!['dev','deploy'].includes(command))throw new Error('Use pages-command.mjs dev or deploy.');
await access(path.join(root,'pages/cloudflare-upload/_worker.js')).catch(()=>{throw new Error('Run npm run build:pages first.');});
await rm(path.join(root,'.wrangler/deploy/config.json'),{force:true});
const require=createRequire(import.meta.url);
const wrangler=path.join(path.dirname(require.resolve('wrangler/package.json')),'bin/wrangler.js');
const child=spawn(process.execPath,[wrangler,'pages',command,'cloudflare-upload',...args],{cwd:path.join(root,'pages'),stdio:'inherit'});
child.on('error',error=>{console.error(error.message);process.exitCode=1;});
child.on('exit',code=>{process.exitCode=code??1;});
