import {pbkdf2Sync,randomBytes} from 'node:crypto';
import {spawn} from 'node:child_process';
import {readFile,writeFile,chmod,mkdir} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const root=fileURLToPath(new URL('..',import.meta.url));
const args=new Set(process.argv.slice(2));
const local=args.has('--local');
const dashboard=args.has('--dashboard');
if([...args].some(x=>!['--local','--dashboard'].includes(x))||(local&&dashboard)){
  console.error('Use: node scripts/admin-secrets.mjs [--local | --dashboard]');
  process.exit(1);
}
function hidden(prompt){
  if(!process.stdin.isTTY)throw new Error('Open an interactive terminal to choose your password.');
  return new Promise((resolve,reject)=>{
    let value='';process.stdout.write(prompt);process.stdin.setRawMode(true);process.stdin.resume();process.stdin.setEncoding('utf8');
    const finish=()=>{process.stdin.off('data',handle);process.stdin.setRawMode(false);process.stdin.pause();process.stdout.write('\n');};
    const handle=chunk=>{
      for(const char of chunk){
        if(char==='\u0003'){finish();reject(new Error('Cancelled'));return;}
        if(char==='\r'||char==='\n'){finish();resolve(value);return;}
        if(char==='\u007f'||char==='\b'){value=Array.from(value).slice(0,-1).join('');}
        else if(char>=' '){value+=char;}
      }
    };
    process.stdin.on('data',handle);
  });
}
try{
  console.log('Admin email: magedsamir996@gmail.com');
  const password=await hidden('Choose a password (16–256 characters): ');
  if(password.length<16||password.length>256)throw new Error('The password must have 16–256 characters.');
  if(password!==await hidden('Confirm password: '))throw new Error('The passwords do not match.');
  const salt=randomBytes(16);
  const secrets={
    ADMIN_PASSWORD_HASH:`pbkdf2-sha256$100000$${salt.toString('base64url')}$${pbkdf2Sync(password,salt,100000,32,'sha256').toString('base64url')}`,
    SESSION_SECRET:randomBytes(32).toString('base64url'),
  };
  if(local){
    const file=path.join(root,'.dev.vars');
    const existing=await readFile(file,'utf8').catch(()=> '');
    const kept=existing.split('\n').filter(line=>!/^\s*(?:ADMIN_EMAIL|ADMIN_PASSWORD_HASH|SESSION_SECRET)\s*=/.test(line)).join('\n').trim();
    const content=(kept?kept+'\n':'')+'ADMIN_EMAIL="magedsamir996@gmail.com"\n'+Object.entries(secrets).map(([key,value])=>`${key}=${JSON.stringify(value)}`).join('\n')+'\n';
    await writeFile(file,content,{mode:0o600});
    await chmod(file,0o600);
    await mkdir(path.join(root,'pages'),{recursive:true});
    await writeFile(path.join(root,'pages/.dev.vars'),content,{mode:0o600});
    console.log('Local admin configured in .dev.vars. Restart the dev server.');
  }else if(dashboard){
    console.log('\nAdd ADMIN_EMAIL = magedsamir996@gmail.com as a Text variable.');
    console.log('Add the following as encrypted Secrets in your Cloudflare project, then redeploy:\n');
    for(const [key,value] of Object.entries(secrets))console.log(key+'\n'+value+'\n');
    console.log('Keep your chosen password private. These values do not need to be included in the website files.');
  }else{
    const require=createRequire(import.meta.url);
    const wrangler=path.join(path.dirname(require.resolve('wrangler/package.json')),'bin/wrangler.js');
    const child=spawn(process.execPath,[wrangler,'secret','bulk','--config','wrangler.jsonc'],{cwd:root,stdio:['pipe','inherit','inherit']});
    child.stdin.end(JSON.stringify(secrets));
    const code=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',resolve);});
    if(code!==0)throw new Error('Cloudflare did not accept the secrets. Log in to Wrangler and retry.');
    console.log('Admin secrets saved. Deploy the project to apply the current code and configuration.');
  }
}catch(error){console.error(error.message);process.exitCode=1;}
