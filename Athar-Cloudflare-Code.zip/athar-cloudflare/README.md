# Athar — نسخة Cloudflare

كود كامل لمتجر الساعات، بواجهة عربية متجاوبة للكمبيوتر وأندرويد وآيفون. افتحي `START-HERE.html` للدليل العربي المختصر والرفع المباشر.

## محتويات النسخة

- كتالوج ٣١ موديلًا، ٦٧ لونًا/تصميمًا، وصور الساعات والشعار. الأسعار ٢٠٠ و٢٥٠ جنيه بحسب كل منتج. الكمية غير محدودة؛ تقدر الإدارة تغير حالة المنتج أو اللون إلى متاح أو نفد.
- متجر عام بدون تسجيل دخول: تفاصيل المنتجات، اختيار الألوان، السلة، حفظ الطلب، وأسعار الشحن لـ٢٧ محافظة.
- إدارة على `/admin`: إضافة وتعديل وحذف المنتجات والصور والألوان والأسعار، التوفر والإخفاء والعروض والترتيب، النصوص والشعار والألوان، الشحن والدفع والتواصل، الطلبات وحالتها وملاحظاتها وطباعة تفاصيلها.
- دخول الإدارة مستقل عن ChatGPT، بالإيميل `magedsamir996@gmail.com` وكلمة مرور تختاريها. لا توجد كلمة مرور افتراضية داخل الكود.
- D1 لحفظ المنتجات والإعدادات والطلبات؛ R2 للصور الجديدة. الجداول والكتالوج يتجهزوا تلقائيًا عند أول زيارة بعد ربط D1.
- الدفع عند الاستلام، والتحويل إلى إنستا باي أو المحفظة بتأكيد يدوي. واتساب اليدوي جاهز؛ الإشعارات التلقائية تحتاج ربط حساب Meta من لوحة الإدارة.

## الرفع المباشر على Cloudflare Pages

١. فكّي ملف الكود. الملف الداخلي `cloudflare-pages-upload.zip` يحتوي النسخة المبنية الجاهزة للرفع، من غير تثبيت أدوات برمجة.

٢. في حسابك على Cloudflare، أنشئي D1 database باسم `athar-store-db`، وR2 bucket باسم `athar-store-images`. يمكن ترك قاعدة D1 الجديدة فارغة؛ التطبيق ينشئ الجداول والمنتجات تلقائيًا.

٣. من **Workers & Pages → Create application → Pages → Drag and drop / Upload assets**، اختاري اسم مشروع متاح وارفعي **الملف الداخلي `cloudflare-pages-upload.zip`** ثم Deploy. بعد إنشاء المشروع، كمّلي إعداداته الآتية في بيئة **Production**:

| المكان | الاسم المطلوب | القيمة |
|---|---|---|
| Settings → Bindings → Add → D1 | `DB` | قاعدة `athar-store-db` |
| Settings → Bindings → Add → R2 | `BUCKET` | مخزن `athar-store-images` |
| Settings → Variables and Secrets → Text | `ADMIN_EMAIL` | `magedsamir996@gmail.com` |
| Settings → Variables and Secrets → Secret، Encrypt | `ADMIN_PASSWORD_HASH` | القيمة التي يولّدها `admin-setup.html` |
| Settings → Variables and Secrets → Secret، Encrypt | `SESSION_SECRET` | القيمة الثانية من `admin-setup.html` |

٤. في إعدادات Functions / Runtime اجعلي **Compatibility date = `2026-05-15`**، وأضيفي **Compatibility flag = `nodejs_compat`**. افتحي `admin-setup.html` على الكمبيوتر لاختيار كلمة المرور وتجهيز قيمتي Secret. أضيفيها إلى المشروع وفق الجدول.

٥. بعد حفظ الإعدادات اعملي **Create a new deployment**، وارفعي نفس الملف الداخلي مرة أخرى في Production. الإعدادات والـbindings تطبّق على النسخة الجديدة. قبل اكتمال ربط `DB` ستظهر رسالة تعذّر تحميل المتجر.

٦. افتحي الرابط الذي يعطيه Cloudflare؛ المتجر يفتح لكل الزوار. ادخلي نفس الرابط مع `/admin` في النهاية، وسجلي بالإيميل وكلمة المرور التي اخترتيها.

يعمل المتجر ولوحة الإدارة في المتصفحات الحديثة. على الموبايل، زر القائمة يفتح الأقسام، والسلة والمنتجات والطلب يمكن استخدامها باللمس.

## تشغيل وتعديل الكود محليًا

ثبتي Node.js بإصدار ٢٢.١٣ أو أحدث. من مجلد المشروع:

```sh
npm install
npm run admin:local
npm run dev
```

أداة `admin:local` تسألك عن كلمة مرور وتأكيدها وتجهّز `.dev.vars` للتجربة المحلية. افتحي الرابط الظاهر في الطرفية. قاعدة البيانات والصور المحلية منفصلتان عن الاستضافة. الجداول تتجهز تلقائيًا. يمكن تطبيق SQL يدويًا عند الحاجة بـ`npm run db:local`.

إصدارات المكتبات المباشرة ثابتة في `package.json`. يوجد أيضًا `pnpm-lock.yaml` بقفل إصدارات الاعتماديات التي استُخدمت في بناء النسخة؛ يمكن استخدام `pnpm install --frozen-lockfile` بدل npm.

| الملف | ما يمكن تعديله |
|---|---|
| `src/store.tsx` | واجهة المتجر، المنتجات، السلة والطلب |
| `src/admin.tsx` | لوحة الإدارة |
| `src/main.tsx` | دخول الإدارة وتشغيل التطبيق |
| `src/globals.css` | التصميم والمقاسات |
| `lib/catalog-snapshot.json` | كتالوج البداية لقاعدة جديدة |
| `lib/settings.ts` | الإعدادات الافتراضية لقاعدة جديدة |
| `public/products/` | صور البداية |
| `worker/` | خدمة البيانات، حفظ الطلبات، الدخول والصور |
| `wrangler.jsonc` | إعداد Workers |
| `pages/wrangler.jsonc` | إعداد Pages عبر أدوات البرمجة |

تعديل كتالوج البداية أو الإعدادات الافتراضية لا يستبدل التعديلات المحفوظة في D1. لتغيير المتجر الموجود استخدمي لوحة الإدارة.

## إعادة بناء نسخة Pages بعد تعديل الكود

```sh
npm run build:pages
npm run preview:pages
```

نسخة الرفع الجديدة ستكون في `pages/cloudflare-upload/`. ارفعي هذا المجلد من لوحة Cloudflare أو اضغطي **محتوياته** في ZIP بحيث يكون `index.html` و`_worker.js` في جذر ZIP. حافظي على نفس قاعدة D1 وR2 حتى تستمر التعديلات والطلبات المحفوظة.

## النشر من الطرفية — للمطور

لتجهيز الموارد:

```sh
npx wrangler login
npx wrangler d1 create athar-store-db
npx wrangler r2 bucket create athar-store-images
```

انسخي `database_id` الحقيقي من نتيجة إنشاء D1 بدل القيمة التجريبية `00000000-0000-4000-8000-000000000000` في `wrangler.jsonc` و`pages/wrangler.jsonc`. عدّلي اسم المشروع وأسماء الموارد إذا اخترتِ أسماء مختلفة. اختيار اسم المشروع في Pages يجب أن يطابق مشروع حسابك.

**Workers مع واجهة المتجر في نفس Worker:**

```sh
npm run admin:setup
npm run deploy
```

`admin:setup` يولّد قيمتي Secret من كلمة المرور ويحمّلهما إلى Worker المحدد في `wrangler.jsonc` عبر Wrangler. يحفظ Cloudflare القيم بشكل Secret. `deploy` يبني الموقع ويرفعه ويطبع رابط `workers.dev`. إعدادات `assets` توجه `/api/*` إلى الخدمة وتوفر بقية الموقع للزوار.

**Pages من الطرفية:** أنشئي مشروع Pages Direct Upload، وأضيفي قيمتي Secret إليه من الداشبورد، ثم:

```sh
npm run admin:dashboard
npm run deploy:pages
```

`admin:dashboard` يعرض قيمًا تولّدت من كلمة المرور لتنسخيها إلى إعدادات المشروع. `deploy:pages` يبني النسخة ثم يرفعها إلى فرع Production المسمى `main`. إن اخترتِ فرعًا آخر، عدّلي `--branch main` في `package.json`.

عند تغيير كلمة المرور، افتحي `admin-setup.html` أو أداة الإعداد من جديد، حدّثي قيمتي Secret وأعيدي النشر. الجلسات السابقة تبطل عند تحديثهما. يمكن تغيير إيميل الإدارة بتحديث `ADMIN_EMAIL` وإعادة النشر.

## التحقق

```sh
npm test
npm run test:pages
```

اختبارات فعلية داخل محاكي Cloudflare على قاعدة وصور اختبار منفصلة: إنشاء D1 تلقائيًا، الكتالوج والصور، الدخول الصحيح والخاطئ، حماية الإدارة، التوفر، إضافة وحذف المنتجات، الإعدادات، طلب الزائر وحساب السعر والشحن من الخادم، منع تكرار الطلب، تحديث حالته، رفع صور R2، استمرار البيانات بعد إعادة تشغيل الخدمة، انتهاء/تلاعب الجلسة وحدّ محاولات الدخول.

تم اجتياز البناء وفحوص الخدمة. التصميم يتضمن قواعد للمقاسات الصغيرة، والتعامل مع اللمس وتكبير الخطوط في حقول الإدخال. لم يتم إجراء اختبار على أجهزة فعلية أو نشر داخل حساب Cloudflare الخاص بك. هذه الحزمة نسخة مستقلة بالكتالوج؛ سجلات الطلبات القديمة وأسرار الاستضافة السابقة غير مضمنة.

## مراجع Cloudflare الرسمية

- [رفع Pages مباشر وملفات `_worker.js`](https://developers.cloudflare.com/pages/get-started/direct-upload/)
- [ربط D1 وR2 ومتغيرات الإدارة](https://developers.cloudflare.com/pages/functions/bindings/)
- [Pages advanced mode](https://developers.cloudflare.com/pages/functions/advanced-mode/)
- [إعداد Wrangler لـPages](https://developers.cloudflare.com/pages/functions/wrangler-configuration/)
- [React وVite على Workers](https://developers.cloudflare.com/workers/framework-guides/web-apps/react/)
